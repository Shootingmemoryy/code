package com.bite.lotterysystem.dao.dataobject;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Shootingmemory
 * @create 2025-03-17-15:21
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Encrypt {
    private String value;


}
