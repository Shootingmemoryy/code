package com.bite.lotterysystem.service.dto;

import lombok.Data;

/**
 * @Shootingmemory
 * @create 2025-03-28-16:58
 */
@Data
public class CreateActivityDTO {

    /**
     * 活动id
     */
    private Long activityId;


}