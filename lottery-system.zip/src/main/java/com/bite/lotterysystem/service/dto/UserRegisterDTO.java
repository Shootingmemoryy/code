package com.bite.lotterysystem.service.dto;

import lombok.Data;

/**
 * @Shootingmemory
 * @create 2025-03-19-16:09
 */
@Data
public class UserRegisterDTO {
    private Long userId;
}
