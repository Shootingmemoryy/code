package com.bite.lotterysystem.controller.result;

import lombok.Data;

import java.io.Serializable;

/**
 * @Shootingmemory
 * @create 2025-03-15-17:52
 */
@Data
public class UserRegisterResult implements Serializable {
    private Long userId;
}
