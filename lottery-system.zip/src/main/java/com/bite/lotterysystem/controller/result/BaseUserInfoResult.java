package com.bite.lotterysystem.controller.result;

import lombok.Data;

/**
 * @Shootingmemory
 * @create 2025-03-26-22:08
 */
@Data
public class BaseUserInfoResult {
    private Long userId;
    private String userName;
    private String identity;
}
